const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ServerPort = new Schema(
  {
    firstname: { type: String },
    lastname: { type: String },
    userType: { type: String },
    email: { type: String },
    password: { type: String }
  },
  {
    collection: "plpproject"
  }
);

module.exports = mongoose.model("ServerPort", ServerPort);
