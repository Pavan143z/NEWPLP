const mongoose= require('mongoose')
const Schema= mongoose.Schema;

const ServerPort = new Schema({
    jobpost:{type: String}
},{
    collection: 'jobpost'
})

module.exports= mongoose.model('jobpost', ServerPort)

