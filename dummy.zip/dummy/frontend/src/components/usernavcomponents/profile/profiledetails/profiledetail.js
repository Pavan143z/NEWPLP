import React, { Component } from "react";
import avatar from "../asserts/profileImage.png";
import UserCard from '../UserCard/UserCard';
import axios from 'axios';
class UserProfile extends Component {

  getProfile = () => {
    axios.get(this.baseurl).then((response) => {
        this.setState({ email: response.data })
        console.log(this.state.email)
    });
}
componentDidMount() {
    this.getProfile();
}
  render() {
    return (
      <div className="Container">
      <div className="content">
  
        <div>
          {/* <a href={'/editprofile'} className="btn btn-danger ">Edit Profile</a>
          <br />
          <br /> */}
          <a href={'/addexp'} className="btn btn-info ">Add Experience</a>
          <br />
          <br />
          <a href={'/addskill'} className="btn btn-primary ">Add Skill</a>
          <br/>
          <br/>
          <a href ={'/showskill'} className="btn btn-info">Show Skill</a>
          <br/>
          <br/>
          <a href={'/showexp'} className="btn btn-primary ">show expiernce</a>
          <br/>
          <br/>
        </div>
      </div>
      </div>
    );
  }
}

export default UserProfile;