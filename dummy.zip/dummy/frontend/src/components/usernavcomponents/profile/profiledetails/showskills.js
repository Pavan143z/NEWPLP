import React, { Component } from 'react'
import UserNavComponent from '../../../usernavcomponent';
import axios from "axios";
export class ShowSkill extends Component {
    constructor() {
        super()
        this.state = { skillset: [] }
    
    }
    baseurl = "  http://localhost:3002/showskill";
    getSkill = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ skillset: response.data })
            console.log(this.state.skillset)
        });
    }
    componentDidMount() {
        this.getSkill();
    }
    render() {
        return (
            <div>
                <UserNavComponent/>
                <h2>My Skills are</h2>
                <h4> {this.state.skillset.map((contact) =>
                <div>
                  <h4 key={contact}>
                  <h4>programming Languages&nbsp;&nbsp; {contact.plang}&nbsp;&nbsp;<br/>skills&nbsp;&nbsp; {contact.skill}</h4>
                 
                  </h4>
                </div>
                )
                }
            </h4>
            </div>
        );
    }
}

export default ShowSkill
