import React, { Component } from 'react'

export class OrgHome extends Component {
  render() {
    return (
      <div>
        <div className="jumbotron text-center">

          <h2>Create a new job post </h2>
          <br />
          <h6>Get your open role in front of qualified candidates.</h6>
          <br />
          <div className="col-md-20">
            <a href="/PostJob" type="submit" className="btn btn-lg btn-primary" value="post a job" >Post a Job</a>
          </div>
        </div>
      </div>
    )
  }
}

export default OrgHome
